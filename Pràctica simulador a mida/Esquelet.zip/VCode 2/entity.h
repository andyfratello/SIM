#pragma once

class CSimulationObject;
class CSimulationEvent;
class CEntity
{
public:
    //Ens cal identificar de forma única les entitats...
    float m_arrivalTime;
    CEntity(){}
    //registra de quan l'entitat entra en el sistema
    CEntity(float currentTime){
        m_arrivalTime=currentTime;
    }
    virtual ~CEntity(){}
    //recuperar el temps de vida
    float getlifeTime(float ara){
        return ara-m_arrivalTime;
    }
private:
    //Recupera la posició on es troba l'entitat
    CSimulationObject* getPlace(){
      return m_objectPlace;
    }
    //Actualitza la posició on es troba l'entitat
    void setPlace(CSimulationObject* receptor){
      m_objectPlace=receptor;
    }
    //Actualitza la traça d'esdeveniments on aquesta entitat s'ha vist implicat
    void traceEvent(CSimulationEvent* event);   
    //Identificador únic de l'entitat 
    int idUnic;
    //Element de simulació on es troba l'entitat
    CSimulationObject* m_objectPlace;
};

