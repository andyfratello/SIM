#include "simulator.h"
#include "simulationevent.h"
#include "eventlist.h"
#include "preObject.h"
#include "postObject.h"
#include "teuObject.h"

CSimulator::CSimulator(){
    //Aquest mètode el podeu canviar si ho creieu necessari
    CPreObject* pre=new CPreObject(this,"preObjecte");
    CPostObject* post=new CPostObject(this,"postObjecte");
    run();
}
CSimulator::~CSimulator(){
    //Eliminem objectes que formen part del model
    while (m_objectes.size()>0)
    {
        delete m_objectes.front();
        m_objectes.pop_front();
    }
    //Eliminem la llista d'esdeveniments
    m_eventList->reset();
    delete m_eventList;
}
void CSimulator::run(){
    simulationStart();
    int a=0;
    while (!simulationFinished() || a<4)
    {
        a=a+1;
        CSimulationEvent* event=(CSimulationEvent*)this->m_eventList->remove();
        m_currentTime=event->getTime();
        event->executed();
        delete event;
    }
    //Recordeu que volem veure estadístics al final de l'execució.
    showEstadistics();
}

void CSimulator::simulationStart()
{
    m_eventList=new CEventList();
    //Feu allò que creieu necessari en base el que hem explicat a teoria i hem vist dins de Flexsim.
}

bool CSimulator::simulationFinished(){
    //Fixeu una condició lògica per a la finalització de forma que el vostre objecte pugui executar tot el procés que s'espera faci
}

void CSimulator::scheduleEvent(CSimulationEvent* event){
    m_eventList->insert(event);
}

void CSimulator::showStatistics(){
    //Feu el que sigui necessari
}